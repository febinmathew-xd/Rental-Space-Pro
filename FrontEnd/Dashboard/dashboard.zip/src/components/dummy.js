{/*import React,{useEffect,useState} from "react";
import { Link } from "react-router-dom";

function Class()
{
  const[roles,setRole]=useState([]);
 const[refresh,setRefresh]=useState(0);
 useEffect(()=>{
  fetch('http://127.0.0.1:8000/api/getrole',{
    method:'get',
    headers:{
        Accept:'application/json',
        'Content-Type':'application/json'
    },
    
}).then((res)=>{
    res.json().then((data)=>{
        console.log(data);
        setRole(data);
    })
})
},[refresh])
const deleteStaffrole=(id)=>{
  let param={
    id:id
  }
  console.log(param);
    fetch("http://127.0.0.1:8000/api/deleterole",{
      method:'POST',
      headers:{
        Accept:'application/json',
        'Content-Type':'application/json'
    },
    body:JSON.stringify(param)
    }).then((res)=>{
      res.json().then((data)=>{
        setRefresh((prev)=>prev+1)
        console.log(data);
      })
    })
}
    return(
        <>
        <div className="content">
            

            <div className="col-sm-12 col-xl-12">
                <div className="bg-secondary rounded h-100 p-4">
                <div className="form-floating mb-3">
                <div className="form-floating">
                        <Link to="/addclass" className="btn btn-primary" style={{backgroundColor:'#16aeeb'}}>AddClass</Link>

                    </div>
                    <div className="col-sm-12 col-xl-12">
                        <div className="row">
                        <div className="form-floating mb-3">
                       
                        <table className="table"><thead>
                        <tr>
                <th>Name</th>
                <th>Action</th>

                  </tr> 
                        </thead>
                        <tbody>
                        {
                            roles.map((values)=>{
                              console.log(values);
                              return(
                            <tr>
                          <td>
                            {values.role}
                          </td>
                          <td>
                        <Link to="/editclass" className="btn btn-primary" style={{backgroundColor:'#16aeeb'}}>EditClass</Link>
                            
                            <a href="" className="btn btn-danger ml-2" onClick={(e)=>{
                              e.preventDefault()
                              deleteStaffrole(values.id)
                            }}>Delete</a>
                          </td>
                          </tr>

                              )

                            })
                          }
                        </tbody>
                        </table>
                        </div>
                            
                        </div>
                        </div>
                        </div>
                </div>
                </div>
                </div>
        </>

    );
}
export default Class;*/}