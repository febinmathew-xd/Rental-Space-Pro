import React, {useState} from 'react'
import { Navigate, useNavigate } from 'react-router-dom'




function AddProduct() {


    const [name, setName] = useState()
    const [price, setPrice] = useState()
    const [description, setDescription] = useState()
    const navigate = useNavigate()
  
    const saveProduct = () =>{
    let param = {
        name: name,
        description: description,
        price : price
    };
    fetch("http://127.0.0.1:8000/api/addproduct").then((response)=>{
        response.json().then((data)=>{
            navigate('/Product')
        });
    });
};





  return (

    //need to add input field for adding product here.. 

    <h1>add product</h1>
  )
}

export default AddProduct