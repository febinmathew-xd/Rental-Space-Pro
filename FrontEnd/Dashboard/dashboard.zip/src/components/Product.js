import React, {useEffect, useState} from "react";
import { Link } from "react-router-dom";



function Product(){
  
    const [products, setProducts] = useState([]);
    const [refresh, setRefresh] = useState(0);

    useEffect(() => {
        fetch("http://127.0.0.1:8000/api/getproducts").then((res) => {
          res.json().then((data) => {
            setProducts(data);
          });
        });
      },[]);

    const productDelete = (id) => {
        let param = {id:id};
        fetch("http://127.0.0.1:8000/api/deleteproducts", {
            method: "POST",
            headers: {
                Accept:"application/json",
                "content-type": "appliction/json"
            },
            body: JSON.stringify(param)
        }).then((response)=> {
            response.json.then((data) => {
                setRefresh((prev)=> prev + 1)
            });
        });
    };

    return(
        <>
    <div className="content">
      <div className="col-sm-12 col-xl-12">
        <div className="bg-secondary rounded h-100 p-4">
          <h6 className="mb-4">ADD PRODUCTS</h6>
          <Link
            to="/AddProduct"
            className="btn btn-primary"
            style={{ backgroundColor: "#16aeeb" }}
          >
            ADD
          </Link>

          {/*<div className="form-floating mb-3">
                                <input type="text" className="form-control" id="floatingInput"
                                    placeholder="Email ID" onChange={(event)=>{
                                        setName(event.target.value)
                                    }}/>
                                   
                               <label for="floatingInput">Name</label>
                            </div>
                            <div className="form-floating mb-3">
                                <input type="text" className="form-control" id="floatingInput"
                                    placeholder="Email ID"  onChange={(event)=>{
                                        setAddress(event.target.value)
                                    }}/>
                                <label for="floatingInput">Address</label>
                            </div>
                            <div className="form-floating mb-3">
                                <input type="email" className="form-control" id="floatingInput"
                                    placeholder="Email ID"  onChange={(event)=>{
                                        setPhone(event.target.value)
                                    }}/>
                                <label for="floatingInput">Phone Number</label>
                            </div>
                            <div className="form-floating mb-3">
                                <input type="email" className="form-control" id="floatingInput"
                                    placeholder="Email ID" onChange={(event)=>{
                                        setEmail(event.target.value)
                                    }}/>
                                <label for="floatingInput">Email ID</label>
                            </div>
                            <div className="form-floating mb-3">
                                <input type="password" className="form-control" id="floatingInput"
                                    placeholder="Email ID" onChange={(event)=>{
                                        setPassword(event.target.value)
                                    }}/>
                                <label for="floatingInput">Password</label>
                                </div>
                                <button onClick={()=>saveVendor()} type="submit ">Save</button>*/}
           <table className="table">
                            <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Description</th>
                                    <th>Image</th>
                                    <th>Price</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    products.map((value)=> {
                                      return(
                                <tr>
                                    <td>{value.name}</td>
                                    <td>{value.description}</td>
                                    <td>img</td>
                                    <td>{value.price}/-</td>
                                    <td>
                                    {/* <Link to='/editProduct'className="btn btn-success" style={{marginRight:12}} state={{id:values.id}}>Edit</Link>
                      <a
                        href=""
                        className="btn btn-danger ml-2"
                        onClick={(e) => {
                          e.preventDefault();
                          vendorDelete(values.id);
                        }}
                      >
                        Delete
                      </a> */}
                                    </td>
                                </tr>
                                      ) ; 
                                    })
                                

                                }
                                    </tbody>
                            </table>
                            </div>
                            </div>
                            </div>
        </>
    )
}
export default Product;