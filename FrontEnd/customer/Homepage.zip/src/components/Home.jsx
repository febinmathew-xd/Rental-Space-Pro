import React from 'react'
import Mouseicon from './mouseicon'
import Sec from './section'
import Footer from './Footer'

function Home() {
  return (
    <main>
     <Mouseicon/>
     <Sec/>
     <Footer/>
    </main>
  )
}

export default Home